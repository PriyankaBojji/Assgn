package Assignment_2_Exs_06_1;
import java.util.Scanner;

public class PersonDetails {
	private String FirstName;
	private String LastName;
	private String Gender;
	private int Age;
	private double Weight;
	PersonDetails(){
		
	}
	PersonDetails(String FirstName,String LastName,String Gender,int Age,double Weight)
	{
		this.FirstName=FirstName;;
		this.LastName=LastName;
		this.Gender=Gender;
		this.Age=Age;
		this.Weight=Weight;
		
	  System.out.println("First Name:"+FirstName+"\nLast Name:"+LastName+"\nGender:"+Gender+"\nage:"+Age+"\nWeight:"+Weight);
	}
	public String getFirstName() {
		try{
			if((FirstName==" ")&&(FirstName=="\n"))
			{
				System.out.println("First name entered is blank");
			}
			}catch(NullPointerException e)
			{
				System.out.println(e.getMessage());
			}
			
		
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		try{
			if((LastName==" ")&&(LastName=="\n"))
			{
				System.out.println("First name entered is blank");
			}
			}catch(NullPointerException e)
			{
				System.out.println(e.getMessage());
			}
			
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public double getWeight() {
		return Weight;
	}
	public void setWeight(double weight) {
		Weight = weight;
	}
	
}

	
	
