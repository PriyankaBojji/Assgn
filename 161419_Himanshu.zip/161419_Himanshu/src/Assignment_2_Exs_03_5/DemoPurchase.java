package Assignment_2_Exs_03_5;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class DemoPurchase {

	public void expiry(){
		DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		System.out.println("Enter Purchase date in dd/MM/yyyy:");
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		String str1 =sc.next();
		LocalDate purchase=LocalDate.parse(str1, formatter1);
		
		System.out.println("Enter Warrantee date in Month:");
		
		int str2 =sc.nextInt();
		
System.out.println("Enter Waranty date in year:");
		
		int str3 =sc.nextInt();
		int mnt = str2 + str3*12;
		LocalDate lt=purchase.plusMonths(mnt);
		System.out.println(lt.format(formatter1));	
	}
	public static void main(String[] args) {
		DemoPurchase pp=new DemoPurchase();
		pp.expiry();
		
	}

}
