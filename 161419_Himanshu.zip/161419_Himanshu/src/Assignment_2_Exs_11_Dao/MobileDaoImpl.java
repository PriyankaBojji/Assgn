package Assignment_2_Exs_11_Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;





import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import Assignment_2_Exs_11_util.DatabaseConnection;
import Assignment_2_Exs_11_Bean.Mobiles;
import Assignment_2_Exs_11_Bean.PurchaseDetails;
import Assignment_2_Exs_11_exception.MobileException;

public class MobileDaoImpl implements IMobileDao{

	//connection
	Connection connection;
	Logger logger=Logger.getRootLogger();
	public MobileDaoImpl() {
	connection = DatabaseConnection.getConnection();
	PropertyConfigurator.configure("./resources/log4j.properties");
	}
	
	//Generate code purchaseId
	private int generateMobileCode() throws MobileException{
		int pId=0;
		try {
			Statement s= connection.createStatement();
			ResultSet rs=s.executeQuery("select purchaseid.nextval from dual");
			if(rs.next())
				pId=rs.getInt(1);
			
		} catch (SQLException e) {
			throw new MobileException(e.getMessage());
		}
		return pId;
		
	}
	
	
	
	//methods
	
	@Override
	public PurchaseDetails addDetails(PurchaseDetails purchase)
			throws MobileException {
		
		
		String sql="insert into purchasedetails"
				+ " (purchaseid,cname,mailid,phoneno,purchasedate,mobileid)"
				+ "  values (?,?,?,?,sysdate,?)";
		
		try {
			int pId=generateMobileCode();
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, pId);
			ps.setString(2, purchase.getCname());
			ps.setString(3, purchase.getMailId());
			ps.setString(4, purchase.getPhoneNo());
			ps.setInt(5, purchase.getMobileId());
			purchase.setPurchaseId(pId);
			//ps.executeUpdate();
			int row=ps.executeUpdate();
			//System.out.println(row+ " inserted.");
			if(row==0)
			{
				logger.error("Insertion failed ");
				throw new MobileException("Inserting purchase details failed ");

			}
			else
			{
				logger.info("Purchase details added successfully:");
			}
		
		}catch(SQLException e){
			logger.error("Mobile Id already exists!!!");
			throw new MobileException("Mobile Id already exists!!!");
		}
	return purchase;
	}

	@Override
	public Mobiles updateDetails(int quantity, int mobileId) throws MobileException {
         String sql="update mobiles set quantity = ?  where mobileid= ?";
		
		Mobiles mobile=new Mobiles();
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, quantity-1);
			ps.setInt(1, mobileId);
			int row= ps.executeUpdate();
			if(row==1)
				mobile.setMobileId(mobileId);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MobileException(e.getMessage());}
		
	return mobile;
	}

	@Override
	public List<Mobiles> getMobileList() throws MobileException {
		String sql="Select * from mobiles";
		List<Mobiles> mobileList = new ArrayList<Mobiles>();
		
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int mid= rs.getInt("mobileid");
				String  name= rs.getString("name");
				int price= rs.getInt("price");
				int quant= rs.getInt("quantity");

				Mobiles mobile=new Mobiles();
				mobile.setMobileId(mid);;
				mobile.setName(name);
				mobile.setPrice(price);
				mobile.setQuantity(quant);;

				mobileList.add(mobile);
			}
			rs.close();
			ps.close();
			} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MobileException(e.getMessage());
		}
		return mobileList;
	}

	@Override
	public Mobiles deleteDetails(int mobileId) throws MobileException {
		
		  String sql="delete from mobiles where mobileid = ?";
			
			Mobiles mobile=new Mobiles();
			try {
				PreparedStatement ps= connection.prepareStatement(sql);
				ps.setInt(1, mobileId);
				int row= ps.executeUpdate();
				if(row==1)
					mobile.setMobileId(mobileId);
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new MobileException(e.getMessage());}
			
		return mobile;
	}

	@Override
	public List<Mobiles> inBetween(int min, int max) throws MobileException {
		String sql="Select * from mobiles where price between ? and ?";
		List<Mobiles> mobileList = new ArrayList<Mobiles>();
		
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, min);
			ps.setInt(2, max);

			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int mid= rs.getInt("mobileid");
				String  name= rs.getString("name");
				int price= rs.getInt("price");
				int quant= rs.getInt("quantity");

				Mobiles mobile=new Mobiles();
				mobile.setMobileId(mid);;
				mobile.setName(name);
				mobile.setPrice(price);
				mobile.setQuantity(quant);;

				mobileList.add(mobile);
			}
			rs.close();
			ps.close();
			} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MobileException(e.getMessage());
		}
		return mobileList;	}
	
}

