package Assignment_2_Exs_11_Dao;

import java.util.List;


import Assignment_2_Exs_11_Bean.Mobiles;
import Assignment_2_Exs_11_Bean.PurchaseDetails;
import Assignment_2_Exs_11_exception.MobileException;

public interface IMobileDao {
	
	public Assignment_2_Exs_11_Bean.PurchaseDetails addDetails(Assignment_2_Exs_11_Bean.PurchaseDetails purchase) throws MobileException;
	public Assignment_2_Exs_11_Bean.Mobiles updateDetails(int quantity, int mobileId) throws MobileException;
	public List<Assignment_2_Exs_11_Bean.Mobiles> getMobileList() throws MobileException;
	public Assignment_2_Exs_11_Bean.Mobiles deleteDetails(int mobileId) throws MobileException;
	public List<Assignment_2_Exs_11_Bean.Mobiles> inBetween(int min, int max) throws MobileException;
	
}
