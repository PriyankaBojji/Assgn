package Assignment_2_Exs_03_1;

public class Concat {

	public Concat() {
		
	}
	
	public void concat( String obj1,String obj2)
	{
 String can= obj1.concat(obj2);
 System.out.println(can);
	}
}
