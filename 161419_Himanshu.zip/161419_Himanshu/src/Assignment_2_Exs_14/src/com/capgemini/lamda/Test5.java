package Assignment_2_Exs_14.src.com.capgemini.lamda;

public interface Test5 {
public int factorial(int x);
}

