package Assignment_2_Exs_14.src.com.capgemini.lamda;

public interface Test4 {
	
	public abstract Test4 getLamdaImp11_11_4(int id,String name,int age);

	}

