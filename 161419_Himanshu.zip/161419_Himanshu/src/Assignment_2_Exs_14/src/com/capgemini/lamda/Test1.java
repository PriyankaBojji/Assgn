package Assignment_2_Exs_14.src.com.capgemini.lamda;

public interface Test1 {
public double power(double x, double y);
}

