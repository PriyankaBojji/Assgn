package Assignment_2_Exs_14.src.com.capgemini.lamda;

public class Test11 {
	public static void main(String[] args) {
		Test1 res = (x, y) -> Math.pow(x, y);
		double result = res.power(10, 2);
		System.out.println(result);
	}
}
