package Assignment_2_Exs_14.src.com.capgemini.lamda;

@FunctionalInterface
public interface Test3 {
	
	boolean valid(String user,String pswrd);

	}
