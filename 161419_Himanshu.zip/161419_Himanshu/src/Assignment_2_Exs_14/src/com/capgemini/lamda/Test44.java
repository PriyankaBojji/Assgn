package Assignment_2_Exs_14.src.com.capgemini.lamda;

class Test44 implements Test4 {
	int age;
	String name;
	int id;

	public Test44(int id, String name, int age) {
		super();
		this.age = age;
		this.name = name;
		this.id = id;
	}

	public Test44 getLamdaImp11_11_4(int id, String name, int age) {
		return null;
	}
}
