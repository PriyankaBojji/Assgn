package Assignment_2_Exs_14.src.com.capgemini.lamda;

import java.util.Scanner;

public class Test55 {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Test5 lb = (x) -> {
			int fact = 1;
			for (int i = 1; i <= x; i++) {
				fact = fact * i;
			}
			return fact;
		};
		System.out.println("enter number");
		Scanner sc = new Scanner(System.in);
		int y = sc.nextInt();
		System.out.println("fact of " + y + " " + lb.factorial(y));
	}
}
