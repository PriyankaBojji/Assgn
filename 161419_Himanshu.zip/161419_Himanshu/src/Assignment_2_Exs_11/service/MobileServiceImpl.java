package Assignment_2_Exs_11.service;

import java.util.ArrayList;
import java.util.List;



import java.util.regex.Matcher;
import java.util.regex.Pattern;




import Assignment_2_Exs_11_Dao.IMobileDao;
import Assignment_2_Exs_11_Dao.MobileDaoImpl;
import Assignment_2_Exs_11_Bean.Mobiles;
import Assignment_2_Exs_11_Bean.PurchaseDetails;
import Assignment_2_Exs_11_exception.MobileException;

public class MobileServiceImpl implements IMobileService {

	//create dao object
	
	IMobileDao dao;
	public MobileServiceImpl(){
		dao = new MobileDaoImpl();
	}
	
	//methods
	
	@Override
	public PurchaseDetails addDetails(PurchaseDetails purchase)
			throws MobileException {
		return dao.addDetails(purchase);
	}

	@Override
	public Mobiles updateDetails(int quantity, int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		return dao.updateDetails(quantity, mobileId);
	}

	@Override
	public List<Mobiles> getMobileList() throws MobileException {
		// TODO Auto-generated method stub
		return dao.getMobileList();
	}

	@Override
	public Mobiles deleteDetails(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		return dao.deleteDetails(mobileId);
	}

	@Override
	public List<Mobiles> inBetween(int min, int max) throws MobileException {
		// TODO Auto-generated method stub
		return dao.inBetween(min, max);
	}

	@Override
	public boolean validateDetails(PurchaseDetails purchase)
			throws MobileException {
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher matcher= pattern.matcher(purchase.getCname());
		if(matcher.matches()){
			pattern= Pattern.compile("[a-z0-9]*@capgemini.com");
			matcher= pattern.matcher(purchase.getMailId());
			if(matcher.matches()){
				pattern= Pattern.compile("[0-9]{10}");
				matcher= pattern.matcher(purchase.getPhoneNo());
			 if(matcher.matches()){
				String str=Integer.toString(purchase.getMobileId());
				pattern= Pattern.compile("[0-9]{4}");
				matcher= pattern.matcher(str);
				if(matcher.matches()){
				return true;
				}
			else 
				throw new MobileException("Invalid Mobile ID.. ");
		   }
		else
			throw new MobileException("Invalid Mobile Number..");
	   }
	else
		throw new MobileException("Invalid Email Id..");
	}
		else
			throw new MobileException("Invalid Customer Name..");		
}//validations end
	

}//class closed