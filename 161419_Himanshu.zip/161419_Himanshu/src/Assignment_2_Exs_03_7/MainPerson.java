package Assignment_2_Exs_03_7;

import java.util.Scanner;

public class MainPerson {
	
	
public static void main(String[] args) {
	Person ps= new Person();

	@SuppressWarnings("resource")
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter First Name:");
	String fname=sc.next();
	System.out.println("Enter Last Name:");
	String lname=sc.next();	
	System.out.println("Enter Gender:");
	String gender=sc.next();
	System.out.println();
	String str = ps.getFullName(fname, lname);
	System.out.println("Full Name:"+str);
	System.out.println("Gender:"+ gender);
	ps.calculateAge();
}


}
